const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise'); // usar promise
require('dotenv').config();

// Pool de conexões
const pool = mysql.createPool({
  host: 'mysql',      // NOME DO SERVIÇO MYSQL
  user: 'admin',
  password: 'senha',
  database: 'disclouddb',
  port: 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Rota de exemplo
router.get('/', async (req, res) => {
  try {
    const [results] = await pool.query('SHOW TABLES;');
    res.json({ tables: results });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

module.exports = router;
